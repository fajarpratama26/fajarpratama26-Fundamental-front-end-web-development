import './script.js'; // src/index.js
import './style.css'; // Menambahkan impor style.css

console.log('Hello, Notes App!');
